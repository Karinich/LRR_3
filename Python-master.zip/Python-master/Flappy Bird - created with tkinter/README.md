# Description:
This is a simple game created with tkinter. <br />
Enjoy and do give feedback <br/>
Warning: If the game is too slow, lower the game resolution in Data/settings.json

# Requirements:
PIL <br />
Python 3.x
